<?php
return [
  'index' => 'controller/IndexController.php',
  'security' => 'controller/SecurityController.php',
  'tasks' => 'controller/TasksController.php',
];
